package com.spring;

import org.springframework.validation.Errors;
import org.springframework.stereotype.Component;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.spring.Student;



@Component
public class StudentValidator implements Validator 
{
   @Override
   public boolean supports(Class<?> c)
   {
      return Student.class.isAssignableFrom(c);
   }

   @Override
   public void validate(Object target, Errors errors)
   {		
	    Student student =(Student)target;
	    ValidationUtils.rejectIfEmpty(errors, "id", "required.user.id");
		ValidationUtils.rejectIfEmpty(errors, "fname", "required.user.fname");	
		ValidationUtils.rejectIfEmpty(errors, "lname", "required.user.lname");
		ValidationUtils.rejectIfEmpty(errors, "etype", "required.user.etype");
		ValidationUtils.rejectIfEmpty(errors, "phoneno", "required.user.phoneno");     
		ValidationUtils.rejectIfEmpty(errors, "mailid", "required.user.mailid");
		ValidationUtils.rejectIfEmpty(errors, "empdoj", "required.user.empdoj");
		ValidationUtils.rejectIfEmpty(errors, "empdesig", "required.user.empdesig");
		ValidationUtils.rejectIfEmpty(errors, "dob", "required.user.dob");
		ValidationUtils.rejectIfEmpty(errors, "mailid2", "required.user.mailid2");
		ValidationUtils.rejectIfEmpty(errors, "mobileno", "required.user.mobileno");
		ValidationUtils.rejectIfEmpty(errors, "phoneno2", "required.user.phoneno2");
		ValidationUtils.rejectIfEmpty(errors, "fathername", "required.user.fathername");
		ValidationUtils.rejectIfEmpty(errors, "eaddress1", "required.user.eaddress1");
		ValidationUtils.rejectIfEmpty(errors, "eaddress2", "required.user.eaddress2");
		ValidationUtils.rejectIfEmpty(errors, "eaddress3", "required.user.eaddress3");
		ValidationUtils.rejectIfEmpty(errors, "previousem", "required.user.previousen");
		ValidationUtils.rejectIfEmpty(errors, "finyear", "required.user.finyear");
		ValidationUtils.rejectIfEmpty(errors, "sdate", "required.user.sdate");
		ValidationUtils.rejectIfEmpty(errors, "edate", "required.user.edate");
		ValidationUtils.rejectIfEmpty(errors, "esalary", "required.user.esalary");
		ValidationUtils.rejectIfEmpty(errors, "taxpaid", "required.user.taxpaid");
 
		if(!student.getMailid().matches("^[a-z][a-zA-Z0-9-_]+[@][a-z]+[.](com|co.in|edu|org)$")){
			 errors.rejectValue("mailid","invalid","Email Id 1 not valid");
			
			 }
		
		if(!student.getMailid2().matches("^[a-z][a-zA-Z0-9-_]+[@][a-z]+[.](com|co.in|edu|org)$")){
			 errors.rejectValue("mailid","invalid", "Email Id 2 not valid");
			 }

		
		if(!String.valueOf(student.getId()).matches("[0-9]")){
			 errors.rejectValue("id", "invalid","Id should be a number");
		}
		
	/*	  if ((student.getPhoneno()!= null) && !(student.getPhoneno().matches("[0-9]")))
		  {
	            errors.rejectValue("phoneno", "invalid","Phone no...1 should be a number");
		  }
		  if ((student.getPhoneno2()!= null) && !(student.getPhoneno2().matches("[0-9]")))
		  {
	            errors.rejectValue("phoneno2", "invalid","Phone no...2 should be a number");
		  }
		  
		if(!(student.getPhoneno().matches("[0-9]"))){
			 errors.rejectValue("phoneno", "invalid","Phone no should be a number");
		 }
	    if(!(student.getPhoneno2().matches("[0-9]"))){
		   errors.rejectValue("phoneno2", "invalid","Phone no2 should be a number");
	       }
	*/  
     }   
}   


 
