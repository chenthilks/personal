package com.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBOperation1 
{
  
  ResultSet rs=null;
  boolean flag=false;
  boolean status=false;
  public  boolean DBOP1(String userName,String password)
  {
	try{  
	        	Class.forName("com.mysql.jdbc.Driver");  
		    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
		     	Statement stmt=con.createStatement();  
				     	
		    	ResultSet rs=stmt.executeQuery("SELECT * FROM sys.ADMIN_INFO WHERE PASSWORD='"+password+"'");		    	   
			
		    	while(rs.next()) 
		    	{	
		    		flag=true;		    	    
		    	}
		    	status=true;
		        con.close();	     
     }	    	 
 catch(Exception e)
     {	    
      	System.out.println(e);
     }	  
   return status;
 }
 public boolean getFlag()
 {
     return flag;    	 
 }
}
