package com.service;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.spring.Student;
/**
 * Servlet implementation class DataEntry
 */

public class DBOperation3
{
	/*
	String employeeFname;
	String employeeLname;
	String employeeType;
	String phoneNo;
	String emailId;
	String employeeDoj;
	String employeeDesignation;
	String employeeDob;
	String emailId2;
	String mobileNo;
	String phoneNo2;
	String fatherName;
	String employeeAddress1;
	String employeeAddress2;
	String employeeAddress3;
	String prevEmpName;
	String finYear;
	String startDate;
	String endDate;
	int employeeSalary;
	String taxPaid;
	*/
	public List listVal=new ArrayList();
	public List listVal2=new ArrayList();
	public List listVal3=new ArrayList();
	
	 //boolean status=false;
	  boolean flag=false;
	  ResultSet rs=null;
	  boolean status=false;
	  int employeeId;
	  String employeeFname;
	  String employeeLname;
	  String employeeType;
	  String phoneNo;
	  String emailId;
	  String employeeDoj;
	  String employeeDesignation;
	  String employeeDob;
	  String emailId2;
	  String mobileNo;
	  String phoneNo2;
	  String fatherName;
	  String employeeAddress1;
	  String employeeAddress2;
	  String employeeAddress3;
	  String prevEmpName;
	  String finYear;
	  String startDate;
	  String endDate;
	  String employeeSalary;
	  String taxPaid;

	public boolean DBOP3(Student student)
	{	
		 employeeId=student.getId();
/*		
	String employeeFname;
	String employeeLname;
	String employeeType;
	String phoneNo;
	String emailId;
	String employeeDoj
	String employeeDesignation;
	String employeeDob;
	String emailId2;
	String mobileNo;
	String phoneNo2;
	String fatherName;
	String employeeAddress1;
	String employeeAddress2;
	String employeeAddress3;
	String prevEmpName;
	String finYear;
	String startDate;
	String endDate;
	String employeeSalary;
	String taxPaid;
	*/
		
		
		//String employee_id=request.getParameter("employee_id");
/*
	    String employee_fname="";
	    String employee_lname="";
	    String employee_type="";
	    String phone_no="";
	    String email_id="";
	    String employee_doj="";
	    String employee_designation="";
	    String employee_dob="";
	    String email_id2="";
	    String mobile_no="";
	    String phone_no2="";
	    String father_name="";
	    String employee_address1="";
	    String employee_address2="";
	    String employee_address3="";
	    String prev_emp_name="";
	    String fin_year="";
	    String start_date="";
	    String end_date="";
	    String employee_salary="";
	    String tax_paid="";
*/	   
	        
		
		    		
		   
		 try{  
		    	Class.forName("com.mysql.jdbc.Driver");  
		    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
		        
		    	Statement stmt=con.createStatement();	
		    	System.out.println(employeeId);
		    	String sql = "select * from sys.EMPLOYEE_PRIMARY_INFO WHERE EMPLOYEE_ID=" +employeeId;
		    	System.out.println ("sql stmt  "+ sql);
		        rs=stmt.executeQuery(sql);  	    	
		        //out.println("<table bgcolor=YELLOW>");
		        //out.println("<tr>");
		     //  if (rs != null)
		   //    {
		       while(rs.next()) 
		    	{	
	                   flag=true;
	     	    	   employeeFname=rs.getString(2);
		    	       System.out.println(employeeFname);
		    		   employeeLname=rs.getString(3);
		    		   employeeType=rs.getString(4);
		    	       phoneNo=rs.getString(5);
		    		   emailId=rs.getString(6);
		    		   employeeDoj=rs.getString(7);	
		    		   employeeDesignation=rs.getString(8);
		    		   System.out.println("rs not equal to null");
		    	       listVal.add(employeeFname);
		    	       listVal.add(employeeLname);
		    	       listVal.add(employeeType);
		    	       listVal.add(phoneNo);
		    	       listVal.add(emailId);
		    	       listVal.add(employeeDoj);
		    	       listVal.add(employeeDesignation);		    	       		    	
		    	}	
		 //      }
		//       else
		 //      {
		 //      System.out.println("rs equals null");
		  //     System.out.println("the value of rs " +rs.toString());
		  //     }       

		        rs=stmt.executeQuery("select * from sys.EMPLOYEE_PERSONAL_INFO WHERE EMPLOYEE_ID="+employeeId);  	    	
		        //out.println("<table bgcolor=YELLOW>");
		        //out.println("<tr>");		      
		        while(rs.next()) 
		    	{	 
		        flag=true;	
		        employeeDob=rs.getString(2);
		        emailId2=rs.getString(3);
		        mobileNo=rs.getString(4);
			    phoneNo2=rs.getString(5);
		        fatherName=rs.getString(6);
			    employeeAddress1=rs.getString(7);
			    employeeAddress2=rs.getString(8);
			    employeeAddress3=rs.getString(9); 
			   
			        listVal2.add(employeeDob);
			        listVal2.add(emailId2);
			        listVal2.add(mobileNo);
			        listVal2.add(phoneNo2);
			        listVal2.add(fatherName);
			        listVal2.add(employeeAddress1);
			        listVal2.add(employeeAddress2);
			        listVal2.add(employeeAddress3);		    	
		    	}		    		        
		       rs=stmt.executeQuery("select * from sys.EMPLOYER_INFO WHERE EMPLOYEE_ID="+employeeId);  	    	
		       //out.println("<table bgcolor=YELLOW>");
		       //out.println("<tr>");		     
		       while(rs.next()) 
		    	{	
		    	    flag=true;
		        	prevEmpName=rs.getString(2);
		        	finYear=rs.getString(3);		    	    
		    	    startDate=rs.getString(4);
		    	    endDate=rs.getString(5);
		    	    employeeSalary=rs.getString(6);
		    	    taxPaid=rs.getString(7);
		    	    //System.out.println(employeeDob);
			        System.out.println(employeeSalary);		    	       
			        listVal3.add(prevEmpName);
			        listVal3.add(finYear);
			        listVal3.add(startDate);
			        listVal3.add(endDate);
			        listVal3.add(employeeSalary);  
			        listVal3.add(taxPaid);
		    	}    
		        
		        
		      /*
		        EmployeeBean bean=new EmployeeBean();
			    bean.setEmployeeFname(employee_fname);
			    bean.setEmployeeLname(employee_lname);
			    bean.setEmployeeId(employee_id);
			    bean.setEmployeeAddress1(employee_address1);
			    System.out.println(employee_address1);
			    bean.setDesignation(employee_designation);
			    bean.setEmployeeSalary(employee_salary);
			    bean.setEmployeeType(employee_type);
		        bean.setEmployeeAddress2(employee_address2);
			    System.out.println(employee_address2);
		        bean.setEmployeeAddress3(employee_address3);
		        System.out.println(employee_address3);
		        bean.setEmployeeDob(employee_dob);
		        bean.setEmployeeDoj(employee_doj);
		        bean.setStart_Date(start_date);
		        bean.setEnd_Date(end_date);
		        bean.setTax_Paid(tax_paid);
		        bean.setPhoneNo(phone_no);
		        bean.setPhoneNo2(phone_no2);
		        bean.setMobileNo(mobile_no);
		        bean.setFatherName(father_name);
		        bean.setEmailId(email_id);
		        bean.setEmailId2(email_id2); 
		        bean.setPrev_Emp_Name(prev_emp_name);
		        bean.setFin_Year(fin_year);
		        */
		        //request.setAttribute("emp_bean",bean); 
		      
			    //RequestDispatcher rd=request.getRequestDispatcher("view/options.jsp");
		        
		       //EmployeeBean emp_bean=(EmployeeBean)request.getAttribute("emp_bean"); 
		       //out.println(emp_bean.getEmployeeSalary());		        
		       //HttpSession session=request.getSession();
		       //session.setAttribute("e_b",bean);		        
		        status=true;
		    	//System.out.println(i+":"+j+":"+k);		        
		        //out.println("</tr>");
		       //out.println("<br/>");
		        //out.println("<br/>");
		    	//out.println("Employee table displayed...");	
		    	con.close();   
		    	 //RequestDispatcher rd=request.getRequestDispatcher("view/login-form3.jsp");
			     // rd.forward(request,response);    
		 
		 }
		    	
		    	catch(Exception e)
		    	{ 
		    	    System.out.println(e);
		    	 //out.println("<br/>");
		    	 //out.println("The exception occured is..."+e);
		    	 //request.setAttribute("exception_message",e.getMessage());
		    	 //RequestDispatcher rd=request.getRequestDispatcher("view/login-form.jsp");
		         //rd.forward(request,response);      
		    	 }	        
			/*
		 public List<Contact> list() {
		 		
		 		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		 		session.beginTransaction();
		 		List<Contact> contacts = null;
		 		try {
		 			
		 			contacts = (List<Contact>)session.createQuery("from Contact").list();
		 			
		 		} catch (HibernateException e) {
		 			e.printStackTrace();
		 			session.getTransaction().rollback();
		 		}
		 		session.getTransaction().commit();
		 		return contacts;
		 	}
		 	*/
		 return status;
	}
	
	 public List getListValue()
	 {
		 System.out.println("........."+listVal);
		 return listVal;
		 
	 }
	 public List getListValue2()
	 {
		  return listVal2;
	 }
	 public List getListValue3()
	 {
		 return listVal3;
	 } 
     public boolean getFlag()
     {
          return flag;    	 
     }
    
}
