package com.service;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.Statement;

import com.spring.Student;

public class DBOperation5 
{
boolean status=false;
boolean flag=false;
int employeeId;
String employeeFname;
String employeeLname;
String employeeType;
String phoneNo;
String emailId;
String employeeDoj;
String employeeDesignation;
String employeeDob;
String emailId2;
String mobileNo;
String phoneNo2;
String fatherName;
String employeeAddress1;
String employeeAddress2;
String employeeAddress3;
String prevEmpName;
String finYear;
String startDate;
String endDate;
String employeeSalary;
String taxPaid;

public  boolean DBOP5(Student student)
{ 
	 
	employeeId=student.getId();

	 try{  
	    	Class.forName("com.mysql.jdbc.Driver");  
	    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
	     	Statement stmt=con.createStatement();  
	
	     	//int i=stmt.executeUpdate("insert into (fname,type) values('"+val1+"','"+val2+"')");

	    	int i=stmt.executeUpdate("DELETE FROM sys.EMPLOYEE_PRIMARY_INFO  WHERE EMPLOYEE_ID='"+employeeId+"' ");
	    	int j=stmt.executeUpdate("DELETE FROM sys.EMPLOYEE_PERSONAL_INFO  WHERE EMPLOYEE_ID='"+employeeId+"' ");  
	        int k=stmt.executeUpdate("DELETE FROM sys.EMPLOYER_INFO  WHERE EMPLOYEE_ID='"+employeeId+"' ");
	    	
	        /* 		
	        ResultSet rs=stmt.executeQuery("select * from test_employee");  	    	
	    	
	    	while(rs.next()) 
	    	{	
	    	System.out.println(rs.getString(1)+" : "+rs.getString(2));  
	    	}
	    	*/	    
	        
	        status=true;
	    	System.out.println(i+":"+j+":"+k);
	    	
	    	if((i==1)&&(j==1)&&(k==1))
	    	{
	    		flag=true;
	    	}
	    	//out.println("<br/>");
	    	//out.println("Employee table updated...");
	    	  con.close();   
	    	}
	    	catch(Exception e)
	    	{ 
	    	 System.out.println(e);
	    	 //out.println("<br/>");
	    	 //out.println("The exception occured is..."+e);
	    	 // request.setAttribute("exception_message",e.getMessage());
	    	 // RequestDispatcher rd=request.getRequestDispatcher("view/login-form.jsp");
	         //rd.forward(request,response);      
	    	}   		
	return status;
	}
public boolean getFlag()
{
     return flag;    	 
}
}

