
import java.io.*;    
public class DataInputStreamExample {  
 public static void main(String[] args) throws IOException {  
    FileInputStream input = new FileInputStream("D:\\testout.txt");  
    DataInputStream inst = new DataInputStream(input);  
    System.out.println(inst.readInt());  
    System.out.println(inst.readDouble());
     
    inst.close();  
    System.out.println("Succcess...");  
  /* int count = input.available();  
    byte[] ary = new byte[count];  
    inst.read(ary);  
    for (byte bt : ary) {  
      char k = (char) bt;  
     System.out.print(k+"-");  
   */
   
   }  
  }  
  
