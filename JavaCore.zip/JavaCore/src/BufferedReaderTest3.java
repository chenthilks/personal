

	import java.io.*;  
	public class BufferedReaderTest3
	{  
	    public static void main(String args[])throws Exception{    
	          FileReader fr=new FileReader("D:\\testout.txt");    
	          BufferedReader br=new BufferedReader(fr);    
	 
	          System.out.println(br.readLine());
	         
	          br.close();    
	          fr.close();    
	    }    
	}    

