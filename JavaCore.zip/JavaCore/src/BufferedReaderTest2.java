

	import java.io.*;  
	public class BufferedReaderTest2
	{  
	    public static void main(String args[])throws Exception{    
	       
	          BufferedReader br=new BufferedReader(new InputStreamReader(System.in));    
	 	       
	          System.out.println("Enter the value");
	          String val=br.readLine();
	          System.out.println(val);
	        
	          br.close();    
	              
	    }    
	}    

