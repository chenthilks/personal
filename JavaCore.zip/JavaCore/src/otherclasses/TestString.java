package otherclasses;

public class TestString
{
		   public static void main(String args[]){
		      String str = "Hello World";
		      System.out.println( "1:"+str.replace( 'H','W' ) );
		      System.out.println( "2:"+str.replaceFirst("He", "Wa") );
		      System.out.println( "3:"+str.replaceAll("He", "Ha") );
		      System.out.println( "4:"+str);
		   }
		}

