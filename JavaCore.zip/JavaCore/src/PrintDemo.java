interface Printable
{  
    int DATA1=100;
	void print();  
}  
interface Showable extends Printable
{  
	 int DATA2=200;
     void show();  
}  

class PrintDemo implements Showable
{  
public void print(){System.out.println("Hello");}  
public void show(){System.out.println("Welcome");}  
 
public static void main(String args[])
 {  
  //DATA1=300;
  //DATA2=400;
  PrintDemo obj = new PrintDemo();  
  obj.print();  
  System.out.println(DATA1);
  obj.show();  
  System.out.println(DATA2);
 }  
}  
