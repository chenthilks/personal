import java.io.IOException;
public class TestSystem {

	public static void main(String[] args) throws IOException
	{
      System.out.println("Enter the values");
	  char c=(char)System.in.read();
      System.out.println(c);
      System.err.println("This is an error");

	}

}
