
    import java.util.ArrayList;  
	import java.util.List;  
	public class ForEachExample
	{  
	    public static void main(String[] args)
	    {  
	    	
	    		   int arr[]={12,13,14,21,44};  
	    		  
	    		   for(int i:arr){  
	    		     System.out.println(i);  
	    		   }  
	    		
	    }  
	}  


