
import static java.lang.System.out;
public class TestStaticImport
{
	public static void main(String args[])
	{
		
		System.out.print("Welcome to ");
		out.print("Java");
	}

}
