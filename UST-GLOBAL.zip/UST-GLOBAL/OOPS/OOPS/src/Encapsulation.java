

class EncapsulationDemo{
    private int serialnum;
    private String name;
    private int age;
    public int getEmpserialnum(){
        return serialnum;
    }
    public String getEmpName(){
        return name;
    }
    public int getEmpAge(){
        return age;
    }
    public void setEmpAge(int newValue){
        age = newValue;
    }
    public void setEmpName(String newValue){
        name = newValue;
    }
    public void setEmpSSN(int newValue){
        serialnum = newValue;
    }
}
public class Encapsulation{
    public static void main(String args[]){
        EncapsulationDemo obj = new EncapsulationDemo();
        obj.setEmpName("XYZ");
        obj.setEmpAge(32);
        obj.setEmpSSN(3121222);
        System.out.println("Employee Name: " + obj.getEmpName());
        System.out.println("Employee Serial number: " + obj.getEmpserialnum());
        System.out.println("Employee Age: " + obj.getEmpAge());
    } 
}
