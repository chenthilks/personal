package time;

import java.time.ZonedDateTime;
import java.time.ZoneId;

public class TestZonedTime {

   public static void main(String args[]) {
	   TestZonedTime java8tester = new TestZonedTime();
      java8tester.testZonedDateTime();
   }
	
   public void testZonedDateTime() {
      // Get the current date and time

		
      ZonedDateTime date2 = ZonedDateTime.now();
      System.out.println("date1: " + date2); 
      
      ZoneId id = ZoneId.of("Europe/Paris");
      System.out.println("ZoneId: " + id);
		
      ZoneId currentZone = ZoneId.systemDefault();
      System.out.println("CurrentZone: " + currentZone);
   }
}