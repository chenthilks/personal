package time;

import java.util.Date;
import java.util.TimeZone; 

	 // class having access to Date class methods
	 
	public class TestDateTime
	{
	    public static void main(String[] args)
	    {
	        Date mydate = new Date();
	 
	        // Displaying the current date and time
	        System.out.println("System date : "+ mydate.toString() );
	 
	        // Is used to set time by milliseconds. Adds 15680 
	        // milliseconds to January 1, 1970 to get new time.
	        TimeZone.setDefault(TimeZone.getTimeZone("America/Chicago"));
	        System.out.println(mydate);

	        TimeZone.setDefault(TimeZone.getTimeZone("Europe/London"));
	        System.out.println(mydate);

	        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Riyadh"));
	        System.out.println(mydate);

	    }
	}
