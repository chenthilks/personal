package otherlistdemos;
import testcollections.Student;

	import java.util.*;      
class TestVector1{      
 public static void main(String args[]){      
	 
	  Vector v=new Vector(); //creating Vector --- Stack --- Dictionary --- HashTable  
	   
	  v.addElement(new Student(111,"WWW",11));
	  v.addElement("irfan");
	  v.addElement(100);  

	  //traversing elements using Enumeration  
	Student refVal1=(Student)v.get(0);
	System.out.println(refVal1.rollno);
	Student refVal2=(Student)v.get(1);
	System.out.println(refVal2);
	Student refVal3=(Student)v.get(2);
	System.out.println(refVal3);
	
	  Vector<String> v1=new Vector<String>(); //creating Vector --- Stack --- Dictionary --- HashTable  
	  v1.addElement("umesh");
	  v1.addElement("irfan");
	  v1.addElement("kumar");  

	  //traversing elements using Enumeration  
	 Enumeration e2=v1.elements();  
	  while(e2.hasMoreElements()){  
	   System.out.println(e2.nextElement());  
	 }  
	}      
      
 }
