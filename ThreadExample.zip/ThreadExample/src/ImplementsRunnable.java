
class ImplementsRunnable implements Runnable{  
public void run(){  
System.out.println("thread is running...");  
}  
  
public static void main(String args[]){  
	ImplementsRunnable m1=new ImplementsRunnable();  
Thread t1 =new Thread(m1);  
t1.start();  
 }  
}  

