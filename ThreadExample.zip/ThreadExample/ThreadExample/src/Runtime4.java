
public class Runtime4 {
	
		public static void main(String args[])throws Exception
		{  
		   
			
			System.out.println(Runtime.getRuntime().availableProcessors());  
			Runtime.getRuntime().exec("notepad");
		
			Runtime r=Runtime.getRuntime();  
			 System.out.println("Total Memory: "+r.totalMemory());  
			 System.out.println("Free Memory: "+r.freeMemory());  
		

			
			
		}  
		}  

