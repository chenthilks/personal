class MethodOverloadingExample{
	public void add(int num1,int num2){
		int result1=num1+num2;
		System.out.println("Result of first method is "+result1);
	}
	public void add(int num1,int num2,int num3){
		int result2=num1+num2+num3;
		System.out.println("Result of overloaded method is "+result2);
	}
}
public class MainMethodOverloading{
	public static void main(String[] args){
		MethodOverloadingExample obj=new MethodOverloadingExample();
		obj.add(10,5,8);
		obj.add(1,5,8);
	}
}
