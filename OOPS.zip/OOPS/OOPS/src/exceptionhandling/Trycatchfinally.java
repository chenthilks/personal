package exceptionhandling;

public class Trycatchfinally {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		  try {
			  int i=10/0;
			   }
		  catch(Exception e)
		 {
			  		System.out.println(e);	  
		 }
	      finally 
	      {System.out.println("Done");}
		  System.out.println("Code after finally");
	}

}
