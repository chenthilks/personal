package exceptionhandling;

import java.io.IOException;

public class TestThrows 
{
 public void readData() throws RuntimeException
 { 
	
   throw new ArithmeticException();	
   
 }
	
	
	
}
