package exceptionhandling;

public class ExceptionCodeHandled{  
	  public static void main(String args[]){  
		   try{  
		      int data=50/0; 
		      System.out.println("Next to try");
		   }
		  catch(Exception e)
		   {
			   System.out.println(e.getMessage());
			}  
		   finally {System.out.println("Cleanup");}
		   
		   System.out.println("rest of the code...");  
		}  
		}  

