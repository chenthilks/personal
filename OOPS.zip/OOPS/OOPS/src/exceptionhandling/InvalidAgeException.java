package exceptionhandling;

public class InvalidAgeException extends Exception
   {  
		 public InvalidAgeException(String s)
		 {  
		  super(s);  
         }  
  }  


