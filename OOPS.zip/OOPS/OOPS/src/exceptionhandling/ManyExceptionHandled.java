package exceptionhandling;

public class ManyExceptionHandled
{  
	  public static void main(String args[]){  
	   try{  
		   String s1="QWERT";
	    int a[]=new int[5];  
	    int c=s1.charAt(10);
	    int b=30/0;  
	    a[5]=100;
	    
	   
	   
	   }  
	     catch(ArithmeticException e)
	   {System.out.println("task1 is completed");}  
	   catch(ArrayIndexOutOfBoundsException e)
	   {System.out.println("task 2 completed");}
	   catch(Exception e){System.out.println("common task completed");} 
		   
	   
	   System.out.println("rest of the code...");  
	 }  
	}  
