class HierarchicalInheritance { 
	void DisplayA() { 
		System.out.println("This is a content of parent class"); 
	} 
} 

//B.java 
class A extends HierarchicalInheritance { 
	void DisplayB() { 
		System.out.println("This is a content of child class 1"); 
	} 
} 

//c.java 
class B extends HierarchicalInheritance { 
	void DisplayC() { 
		System.out.println("This is a content of child class 2"); 
	} 
} 

//MainClass.java 
 public class InheritanceDemo 
{ 
	public static void main(String args[]) { 
		System.out.println("Calling for child class A"); 
		A a = new A(); 
		a.DisplayA();
		a.DisplayB();
		System.out.println("Calling for child class B"); 
		B b = new B(); 
		b.DisplayA(); 
		b.DisplayC(); 
		
	} 
} 
