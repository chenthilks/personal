package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DataEntry3S
{
  	public void store(String employee_id) throws Exception
  	{
	Class.forName("com.mysql.jdbc.Driver");  
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  

	Statement stmt=con.createStatement();  

	//int i=stmt.executeUpdate("insert into (fname,type) values('"+val1+"','"+val2+"')");
     int i=stmt.executeUpdate("DELETE FROM sys.EMPLOYEE_PRIMARY_INFO  WHERE EMPLOYEE_ID='"+employee_id+"' ");
     int j=stmt.executeUpdate("DELETE FROM sys.EMPLOYEE_PERSONAL_INFO  WHERE EMPLOYEE_ID='"+employee_id+"' ");  
     int k=stmt.executeUpdate("DELETE FROM sys.EMPLOYER_INFO  WHERE EMPLOYEE_ID='"+employee_id+"' ");
     con.close();   			        
   /* 		
   ResultSet rs=stmt.executeQuery("select * from test_employee");  	    	
	
	while(rs.next()) 
	{	
	System.out.println(rs.getString(1)+" : "+rs.getString(2));  
	}
	*/	    	
	//System.out.println(i+":"+j+":"+k);

  	}
}
