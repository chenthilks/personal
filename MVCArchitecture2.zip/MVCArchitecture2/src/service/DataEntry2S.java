package service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.Statement;

public class DataEntry2S
{
	public void store(String employee_id,String employee_fname,String employee_lname,String employee_type,String phone_no,String email_id,String employee_doj,String employee_designation,String employee_dob,String phone_no2,String father_name,String employee_address1,String employee_address2,String employee_address3,String previous_employer_name,String fin_year,String start_date,String end_date,String employee_salary,String CREATED_BY_USER,Date CREATED_BY_DATE,String MODIFIED_BY_USER,Date MODIFIED_BY_DATE) throws Exception
{
	
		Class.forName("com.mysql.jdbc.Driver");  
    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
    
    	Statement stmt=con.createStatement();  

    	//int i=stmt.executeUpdate("insert into (fname,type) values('"+val1+"','"+val2+"')");
        int i=stmt.executeUpdate("UPDATE sys.EMPLOYEE_PRIMARY_INFO SET EMPLOYEE_FNAME='"+employee_fname+"',EMPLOYEE_LNAME='"+employee_lname+"',EMPLOYEE_TYPE='"+employee_type+"',PHONE_NO='"+phone_no+"',EMAIL_ID='"+email_id+"',EMPLOYEE_DOJ='"+employee_doj+"',EMPLOYEE_DESIGNATION='"+employee_designation+"',CREATED_BY_USER='"+CREATED_BY_USER+"',CREATED_BY_DATE='"+CREATED_BY_DATE+"',MODIFIED_BY_USER='"+MODIFIED_BY_USER+"',MODIFIED_BY_DATE='"+MODIFIED_BY_DATE+"' WHERE EMPLOYEE_ID='"+employee_id+"' ");
        int j=stmt.executeUpdate("UPDATE sys.EMPLOYEE_PERSONAL_INFO SET EMPLOYEE_DOB='"+employee_dob+"',PHONE_NO2='"+phone_no2+"',FATHER_NAME='"+father_name+"',EMPLOYEE_ADDRESS1='"+employee_address1+"',EMPLOYEE_ADDRESS2='"+employee_address2+"',EMPLOYEE_ADDRESS3='"+employee_address3+"',CREATED_BY_USER='"+CREATED_BY_USER+"',CREATED_BY_DATE='"+CREATED_BY_DATE+"',MODIFIED_BY_USER='"+MODIFIED_BY_USER+"',MODIFIED_BY_DATE='"+MODIFIED_BY_DATE+"' WHERE EMPLOYEE_ID='"+employee_id+"' "); 
        int k=stmt.executeUpdate("UPDATE sys.EMPLOYER_INFO SET PREVIOUS_EMPLOYER_NAME='"+previous_employer_name+"',FIN_YEAR='"+fin_year+"',START_DATE='"+start_date+"',END_DATE='"+end_date+"',EMPLOYEE_SALARY='"+employee_salary+"',CREATED_BY_USER='"+CREATED_BY_USER+"',CREATED_BY_DATE='"+CREATED_BY_DATE+"',MODIFIED_BY_USER='"+MODIFIED_BY_USER+"',MODIFIED_BY_DATE='"+MODIFIED_BY_DATE+"' WHERE EMPLOYEE_ID= '"+employee_id+"' " );
        con.close(); 
        
       /* 		
       ResultSet rs=stmt.executeQuery("select * from test_employee");  	    	
    	
    	while(rs.next()) 
    	{	
    	System.out.println(rs.getString(1)+" : "+rs.getString(2));  
    	}
    	*/	    	
    	//System.out.println(i+":"+j+":"+k);
    	

}


}
