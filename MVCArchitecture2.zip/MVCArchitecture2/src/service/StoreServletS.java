package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;


public class StoreServletS
{
	
	public void store(String employee_id,String employee_fname,String employee_lname,String employee_type,String phone_no,String email_id,String employee_doj,String employee_designation,String employee_dob,String phone_no2,String father_name,String employee_address1,String employee_address2,String employee_address3,String previous_employer_name,String fin_year,String start_date,String end_date,String employee_salary,String CREATED_BY_USER,Date CREATED_BY_DATE,String MODIFIED_BY_USER,Date MODIFIED_BY_DATE) throws Exception
	{
		
	
	    	Class.forName("com.mysql.jdbc.Driver");  
	    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
	    
	    	Statement stmt=con.createStatement();  
	
	    	//int i=stmt.executeUpdate("insert into (fname,type) values('"+val1+"','"+val2+"')");
	    	
	    	int i=stmt.executeUpdate("insert into sys.EMPLOYEE_PRIMARY_INFO(EMPLOYEE_ID,EMPLOYEE_FNAME,EMPLOYEE_LNAME,EMPLOYEE_TYPE,PHONE_NO,EMAIL_ID,EMPLOYEE_DOJ,EMPLOYEE_DESIGNATION,CREATED_BY_USER,CREATED_BY_DATE,MODIFIED_BY_USER,MODIFIED_BY_DATE) VALUES ('"+employee_id+"','"+employee_fname+"','"+employee_lname+"','"+employee_type+"','"+phone_no+"','"+email_id+"','"+employee_doj+"','"+employee_designation+"','"+CREATED_BY_USER+"','"+CREATED_BY_DATE+"','"+MODIFIED_BY_USER+"','"+MODIFIED_BY_DATE+"')");
	        int j=stmt.executeUpdate("insert into sys.EMPLOYEE_PERSONAL_INFO(EMPLOYEE_ID,EMPLOYEE_DOB,PHONE_NO2,FATHER_NAME,EMPLOYEE_ADDRESS1,EMPLOYEE_ADDRESS2,EMPLOYEE_ADDRESS3,CREATED_BY_USER,CREATED_BY_DATE,MODIFIED_BY_USER,MODIFIED_BY_DATE) VALUES ('"+employee_id+"','"+employee_dob+"','"+phone_no2+"','"+father_name+"','"+employee_address1+"','"+employee_address2+"','"+employee_address3+"','"+CREATED_BY_USER+"','"+CREATED_BY_DATE+"','"+MODIFIED_BY_USER+"','"+MODIFIED_BY_DATE+"' )"); 
	        int k=stmt.executeUpdate("insert into sys.EMPLOYER_INFO(EMPLOYEE_ID,PREVIOUS_EMPLOYER_NAME,FIN_YEAR,START_DATE,END_DATE,EMPLOYEE_SALARY,CREATED_BY_USER,CREATED_BY_DATE,MODIFIED_BY_USER,MODIFIED_BY_DATE)VALUES ('"+employee_id+"','"+previous_employer_name+"','"+fin_year+"','"+start_date+"','"+end_date+"','"+employee_salary+"','"+CREATED_BY_USER+"','"+CREATED_BY_DATE+"','"+MODIFIED_BY_USER+"','"+MODIFIED_BY_DATE+"')");
	    	
	       /* 		
	       ResultSet rs=stmt.executeQuery("select * from test_employee");  	    	
	    	
	    	while(rs.next()) 
	    	{	
	    	System.out.println(rs.getString(1)+" : "+rs.getString(2));  
	    	}
	    	*/	    	
	    	System.out.println(i+":"+j+":"+k);
	    	
	        //out.println("Employee table updated...");
	    	//emp_obj.invalidate();
	    	con.close();   
	    	
	    		        


	}

}
