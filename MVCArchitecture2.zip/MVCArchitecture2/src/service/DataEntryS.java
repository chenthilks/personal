package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DataEntryS
{
public ResultSet store1(String employee_id)throws Exception
{
     
	    	Class.forName("com.mysql.jdbc.Driver");  
	    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
	    
	    	Statement stmt=con.createStatement();		         		
	    	ResultSet rs=stmt.executeQuery("select * from sys.EMPLOYEE_PRIMARY_INFO WHERE EMPLOYEE_ID='"+employee_id+"'");  	    	
	    	//con.close();
	    	return rs;  
	        
 }
public ResultSet store2(String employee_id)throws Exception
{
	Class.forName("com.mysql.jdbc.Driver");  
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
	Statement stmt=con.createStatement();		  
	ResultSet rs=stmt.executeQuery("select * from sys.EMPLOYEE_PRIMARY_INFO WHERE EMPLOYEE_ID='"+employee_id+"'");  	    	
   //con.close();
	return rs;  
}
public ResultSet store3(String employee_id)throws Exception
{
	Class.forName("com.mysql.jdbc.Driver");  
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
	Statement stmt=con.createStatement();		  
	ResultSet rs=stmt.executeQuery("select * from sys.EMPLOYEE_PRIMARY_INFO WHERE EMPLOYEE_ID='"+employee_id+"'");  	    	
 // con.close();
	return rs;  
}

}