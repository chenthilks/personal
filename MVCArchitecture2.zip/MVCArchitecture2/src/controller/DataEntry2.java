package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.EmployeeBean;
import service.DataEntry2S;

/**
 * Servlet implementation class DataEntry2
 */
@WebServlet("/DataEntry2")
public class DataEntry2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataEntry2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
	
		

		
		response.setContentType("text/html");
	    PrintWriter out=response.getWriter();
	    HttpSession emp_obj=request.getSession();
	    EmployeeBean emp_bean=(EmployeeBean)emp_obj.getAttribute("e_b");	
	    
	    String employee_id=emp_bean.getEmployeeId();
	    String employee_fname=emp_bean.getEmployeeFname();
	    String employee_lname=emp_bean.getEmployeeLname();
	    String employee_type=emp_bean.getEmployeeType();
	    String phone_no=emp_bean.getPhoneNo();
	    String email_id=emp_bean.getEmailId();
	    String employee_designation=emp_bean.getDesignation();
	    
	    String employee_dob=emp_bean.getEmployeeDob();
	    String employee_doj=emp_bean.getEmployeeDoj();
	    String phone_no2=emp_bean.getPhoneNo2();
	    String father_name=emp_bean.getFatherName();
	    String employee_address1=emp_bean.getEmployeeAddress1();
	    System.out.println(employee_address1);
	    String employee_address2=emp_bean.getEmployeeAddress2();
	    System.out.println(employee_address2);
	    String employee_address3=emp_bean.getEmployeeAddress3();
	    System.out.println(employee_address3);
	    String previous_employer_name=emp_bean.getPrev_Emp_Name();
	    String fin_year=emp_bean.getFin_Year();
	    String start_date=emp_bean.getStart_Date();
	    String end_date=emp_bean.getEnd_Date();
	    String employee_salary=emp_bean.getEmployeeSalary();
	    
			     
				
			    
			    out.println("Welcome,"+employee_fname);
			    out.println("<br/>");
			    out.println("Designation,"+employee_designation);    
			    out.println("<br/>");
			    out.println("The database connection goes here...");
			    String CREATED_BY_USER="NEWUSER"; //(String)emp_obj.getAttribute("CREATED_BY_USER");
			    //Date CREATED_BY_DATE2=new Date("2001-12-12");//(Long)emp_obj.getAttribute("CREATED_BY_DATE");
			    Date CREATED_BY_DATE=new Date(0);
			    //String MODIFIED_BY_USER=request.getParameter("MODIFIED_BY_USER");
			    String MODIFIED_BY_USER=CREATED_BY_USER;
			    //Long MODIFIED_BY_DATE2=Long.parseLong(request.getParameter("MODIFIED_BY_DATE"));
			    Date MODIFIED_BY_DATE=CREATED_BY_DATE;
			  //SSS
			    
			    try{  
			    	DataEntry2S ref=new DataEntry2S();
			    	ref.store(employee_id, employee_fname, employee_lname, employee_type, phone_no, email_id, employee_doj, employee_designation, employee_dob, phone_no2, father_name, employee_address1, employee_address2, employee_address3, previous_employer_name, fin_year, start_date, end_date, employee_salary, CREATED_BY_USER, CREATED_BY_DATE, MODIFIED_BY_USER, MODIFIED_BY_DATE);
			        
			    	out.println("<br/>");
			    	out.println("Employee table updated...");
			    	emp_obj.invalidate();
			    	  

			    }
			    	
			    	catch(Exception e)
			    	{ 
			    	//System.out.println(e);
			    	 out.println("<br/>");
			    	 //out.println("The exception occured is..."+e);
			    	 request.setAttribute("exception_message",e.getMessage());
			    	 RequestDispatcher rd=request.getRequestDispatcher("view/login-form2.jsp");
			         rd.forward(request,response);      
			    	 }	        

	
	}

}
