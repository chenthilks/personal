package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement; 
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.LoginBean;

/**
 * Servlet implementation class ControllerServlet
 */
@WebServlet("/ControllerServlet")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
	    
		  response.setContentType("text/html");
		  PrintWriter out=response.getWriter();
		 
		  String name=request.getParameter("name");
		  String password=request.getParameter("password");
		  
	     
		 
	      LoginBean bean=new LoginBean();
	      bean.setName(name);
	      bean.setPassword(password);
	      request.setAttribute("bean",bean);
		
	      //boolean status=bean.validate();
	
	      boolean status=false;
	     
	     try{  
		    	Class.forName("com.mysql.jdbc.Driver");  
		    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
		    
		    	Statement stmt=con.createStatement();  
				    	    	
		    	ResultSet rs=stmt.executeQuery("SELECT * FROM sys.ADMIN_INFO WHERE PASSWORD='"+password+"'");
		    	
		      
		   	
		    	
		    	while(rs.next()) 
		    	{	
		    	    status=true;
		    	}
		    	    	
		         	con.close();   
		  	}
		    	
	     
	     
	     catch(Exception e)
	     {
	    
	    	 System.out.println(e);
	    	 out.println("<br/>");
	    	 out.println("The exception occured is..."+e);
		    	  
		 }	        
	     
	     if(status)
	     {
		   RequestDispatcher rd=request.getRequestDispatcher("view/login-success2.jsp");
		   rd.forward(request,response);
	     }	
	     else
	     {
		    RequestDispatcher rd=request.getRequestDispatcher("view/login-error.jsp");
		    rd.forward(request,response);
	     }	
	
	} 
}
