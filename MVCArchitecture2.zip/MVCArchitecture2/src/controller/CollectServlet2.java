package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.EmployeeBean;

/**
 * Servlet implementation class CollectServlet
 */
@WebServlet("/CollectServlet2")
public class CollectServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CollectServlet2() 
    {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub    		
    }
/**
 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		 response.setContentType("text/html");
		 PrintWriter out=response.getWriter();
		 
		 String employee_id=request.getParameter("employee_id");
		 String employee_fname=request.getParameter("employee_fname");	
		 System.out.println(employee_fname);
		 String employee_lname=request.getParameter("employee_lname");	
		 String employee_type=request.getParameter("employee_type");
		 String employee_designation=request.getParameter("employee_designation");		 
		 String employee_dob=request.getParameter("employee_dob");
		 String employee_doj=request.getParameter("employee_doj");
		 String employee_address1=request.getParameter("employee_address1");
		 System.out.println(employee_address1);
		 String employee_address2=(String)request.getParameter("employee_address2");
		 System.out.println(employee_address2);
		 String employee_address3=(String)request.getParameter("employee_address3");
		 System.out.println(employee_address3);
		 String phone_no=request.getParameter("phone_no");
		 String phone_no2=request.getParameter("phone_no2");
		 String father_name=request.getParameter("father_name");
		 String email_id=request.getParameter("email_id");
		 String email_id2=request.getParameter("email_id2");
		 String mobile_no=request.getParameter("mobile_no");
		 String fin_year=request.getParameter("fin_year");
		 String prev_emp_name=request.getParameter("prev_emp_name");	    
		 String start_date=request.getParameter("start_date");		 
		 String end_date=request.getParameter("end_date");
		 String employee_salary=request.getParameter("employee_salary");
	     String tax_paid=request.getParameter("tax_paid");
	      	     
	     EmployeeBean bean=new EmployeeBean();
	     bean.setEmployeeFname(employee_fname);
	     bean.setEmployeeLname(employee_lname);
	     bean.setEmployeeId(employee_id);
	     bean.setEmployeeAddress1(employee_address1);
	     System.out.println(employee_address1);
	     bean.setDesignation(employee_designation);
	     bean.setEmployeeSalary(employee_salary);
	     bean.setEmployeeType(employee_type);
         bean.setEmployeeAddress2(employee_address2);
	     System.out.println(employee_address2);
         bean.setEmployeeAddress3(employee_address3);
         System.out.println(employee_address3);
        
        bean.setEmployeeDob(employee_dob);
        bean.setEmployeeDoj(employee_doj);
        bean.setStart_Date(start_date);
        bean.setEnd_Date(end_date);
        bean.setTax_Paid(tax_paid);
        bean.setPhoneNo(phone_no);
        bean.setPhoneNo2(phone_no2);
        bean.setMobileNo(mobile_no);
        bean.setFatherName(father_name);
        bean.setEmailId(email_id);
        bean.setEmailId2(email_id2); 
        bean.setPrev_Emp_Name(prev_emp_name);
        bean.setFin_Year(fin_year);
        
    //  request.setAttribute("emp_bean",bean); 
      
   //   RequestDispatcher rd=request.getRequestDispatcher("view/options.jsp");
  //    EmployeeBean emp_bean=(EmployeeBean)request.getAttribute("emp_bean"); 
 //     out.println(emp_bean.getEmployeeSalary());
        
        HttpSession session=request.getSession();
        session.setAttribute("e_b",bean); 
     //   EmployeeBean emp_bean2=(EmployeeBean)session.getAttribute("e_b");      
     //  out.println(emp_bean2.getEmployeeSalary());          
        RequestDispatcher rd=request.getRequestDispatcher("DataEntry2");
        rd.forward(request,response);
	}

}
