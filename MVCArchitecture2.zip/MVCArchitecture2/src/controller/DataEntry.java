package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.EmployeeBean;
import service.DataEntryS;

/**
 * Servlet implementation class DataEntry
 */
@WebServlet("/DataEntry")
public class DataEntry extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataEntry() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	   // TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
	    PrintWriter out=response.getWriter();
	    out.println("<br/>");
		out.println("This servlet is to view the data");
	   	
		out.println("<br/>");
		    String employee_id=request.getParameter("employee_id");

		    String employee_fname="";
		    String employee_lname="";
		    String employee_type="";
		    String phone_no="";
		    String email_id="";
		    String employee_doj="";
		    String employee_designation="";
		    String employee_dob="";
		    String email_id2="";
		    String mobile_no="";
		    String phone_no2="";
		    String father_name="";
		    String employee_address1="";
		    String employee_address2="";
		    String employee_address3="";
		    String prev_emp_name="";
		    String fin_year="";
		    String start_date="";
		    String end_date="";
		    String employee_salary="";
		    String tax_paid="";
		    ResultSet rs;
		    
		   
		//SSS
		    /*Class.forName("com.mysql.jdbc.Driver");  
	    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
	    
	    	Statement stmt=con.createStatement();		         		
	    	ResultSet rs=stmt.executeQuery("select * from sys.EMPLOYEE_PRIMARY_INFO WHERE EMPLOYEE_ID='"+employee_id+"'");
		  */  try {
		    	DataEntryS dataS=new DataEntryS();
		    	rs=dataS.store1(employee_id);
		    	
		      out.println("<table bgcolor=YELLOW>");
		        out.println("<tr>");
		        while(rs.next()) 
		    	{	
		    	       employee_fname=rs.getString(2);
		    			     employee_lname=rs.getString(3);
		    			    employee_type=rs.getString(4);
		    			    phone_no=rs.getString(5);
		    			     email_id=rs.getString(6);
		    			     employee_doj=rs.getString(7);	
		    			     employee_designation=rs.getString(8);
		   	       }	
		        
		        rs=dataS.store2(employee_id);  	    	
		        out.println("<table bgcolor=YELLOW>");
		        out.println("<tr>");
		        while(rs.next()) 
		    	{	 
		       employee_dob=rs.getString(2);
			   phone_no2=rs.getString(3);
			  father_name=rs.getString(4);
			    employee_address1=rs.getString(5);
			    employee_address2=rs.getString(6);
			    employee_address3=rs.getString(7); 	           
		    	}		    
		        
		       rs=dataS.store3(employee_id);  	
		        out.println("<table bgcolor=YELLOW>");
		        out.println("<tr>");
		        while(rs.next()) 
		    	{	 
		        	 prev_emp_name=rs.getString(2);
		    	    fin_year=rs.getString(3);		    	    
		    	    start_date=rs.getString(4);
		    	    end_date=rs.getString(5);
		    	    employee_salary=rs.getString(6);
		    	}		    
		        
		        EmployeeBean bean=new EmployeeBean();
			     bean.setEmployeeFname(employee_fname);
			     bean.setEmployeeLname(employee_lname);
			     bean.setEmployeeId(employee_id);
			     bean.setEmployeeAddress1(employee_address1);
			     System.out.println(employee_address1);
			     bean.setDesignation(employee_designation);
			     bean.setEmployeeSalary(employee_salary);
			     bean.setEmployeeType(employee_type);
		         bean.setEmployeeAddress2(employee_address2);
			     System.out.println(employee_address2);
		         bean.setEmployeeAddress3(employee_address3);
		         System.out.println(employee_address3);
		        bean.setEmployeeDob(employee_dob);
		        bean.setEmployeeDoj(employee_doj);
		        bean.setStart_Date(start_date);
		        bean.setEnd_Date(end_date);
		        bean.setTax_Paid(tax_paid);
		        bean.setPhoneNo(phone_no);
		        bean.setPhoneNo2(phone_no2);
		        bean.setMobileNo(mobile_no);
		        bean.setFatherName(father_name);
		        bean.setEmailId(email_id);
		        bean.setEmailId2(email_id2); 
		        bean.setPrev_Emp_Name(prev_emp_name);
		        bean.setFin_Year(fin_year);
		        
		       // request.setAttribute("emp_bean",bean); 
		      
			//  RequestDispatcher rd=request.getRequestDispatcher("view/options.jsp");
		        
		    //    EmployeeBean emp_bean=(EmployeeBean)request.getAttribute("emp_bean"); 
		   //     out.println(emp_bean.getEmployeeSalary());
		        
		        HttpSession session=request.getSession();
		        session.setAttribute("e_b",bean); 
		        
		        out.println("</tr>");
		       	out.println("<br/>");
		        out.println("<br/>");
		    	out.println("Employee table displayed...");	
		    	//SSS   	con.close();   
		    	 RequestDispatcher rd=request.getRequestDispatcher("view/login-form3.jsp");
			      rd.forward(request,response);      
			       
		 
		 }
		    	
		    	catch(Exception e)
		    	{ 
		    	    System.out.println(e);
		    	 //out.println("<br/>");
		    	 //out.println("The exception occured is..."+e);
		    	 //request.setAttribute("exception_message",e.getMessage());
		    	 //RequestDispatcher rd=request.getRequestDispatcher("view/login-form.jsp");
		         //rd.forward(request,response);      
		    	 }	        

		
		
	}

}
