package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement; 
import java.sql.ResultSet;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.EmployeeBean;
import service.StoreServletS;


/**
 * Servlet implementation class StoreServlet
 */
@WebServlet("/StoreServlet")
public class StoreServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StoreServlet()
    {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
	
}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		response.setContentType("text/html");
	    PrintWriter out=response.getWriter();
	    HttpSession emp_obj=request.getSession();
	    EmployeeBean emp_bean=(EmployeeBean)emp_obj.getAttribute("e_b");	
	    
	    String employee_id=emp_bean.getEmployeeId();
	    String employee_fname=emp_bean.getEmployeeFname();
	    String employee_lname=emp_bean.getEmployeeLname();
	    String employee_type=emp_bean.getEmployeeType();
	    String phone_no=emp_bean.getPhoneNo();
	    String email_id=emp_bean.getEmailId();
	    String employee_designation=emp_bean.getDesignation();
	    
	    String employee_dob=emp_bean.getEmployeeDob();
	    String employee_doj=emp_bean.getEmployeeDoj();
	    String phone_no2=emp_bean.getPhoneNo2();
	    String father_name=emp_bean.getFatherName();
	    String employee_address1=emp_bean.getEmployeeAddress1();
	    String employee_address2=emp_bean.getEmployeeAddress2();
	    System.out.println(employee_address2);
	    String employee_address3=emp_bean.getEmployeeAddress3();
	    System.out.println(employee_address3);
	    String previous_employer_name=emp_bean.getPrev_Emp_Name();
	    String fin_year=emp_bean.getFin_Year();
	    String start_date=emp_bean.getStart_Date();
	    String end_date=emp_bean.getEnd_Date();
	    String employee_salary=emp_bean.getEmployeeSalary();
        out.println("Welcome,"+employee_fname);
	    out.println("<br/>");
	    out.println("Designation,"+employee_designation);    
	    out.println("<br/>");
	    out.println("The database connection goes here...");
	    String CREATED_BY_USER=(String)emp_obj.getAttribute("CREATED_BY_USER");
	    Long CREATED_BY_DATE2=(Long)emp_obj.getAttribute("CREATED_BY_DATE");
	    Date CREATED_BY_DATE=new Date(CREATED_BY_DATE2);
	    //String MODIFIED_BY_USER=request.getParameter("MODIFIED_BY_USER");
	    String MODIFIED_BY_USER=CREATED_BY_USER;
	    //Long MODIFIED_BY_DATE2=Long.parseLong(request.getParameter("MODIFIED_BY_DATE"));
	    Date MODIFIED_BY_DATE=CREATED_BY_DATE;
//SSS
	   try{  
	                StoreServletS storeS=new StoreServletS();
	            	storeS.store(employee_id,employee_fname,employee_lname,employee_type,phone_no,email_id,employee_doj,employee_designation,employee_dob,phone_no2,father_name,employee_address1,employee_address2,employee_address3,previous_employer_name,fin_year,start_date,end_date,employee_salary,CREATED_BY_USER,CREATED_BY_DATE,MODIFIED_BY_USER,MODIFIED_BY_DATE);
	      }
	    	   /*
	    	
	        Class.forName("com.mysql.jdbc.Driver");  
	    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
	    
	    	Statement stmt=con.createStatement();  
	
	    	//int i=stmt.executeUpdate("insert into (fname,type) values('"+val1+"','"+val2+"')");
	    	
	    	int i=stmt.executeUpdate("insert into sys.EMPLOYEE_PRIMARY_INFO(EMPLOYEE_ID,EMPLOYEE_FNAME,EMPLOYEE_LNAME,EMPLOYEE_TYPE,PHONE_NO,EMAIL_ID,EMPLOYEE_DOJ,EMPLOYEE_DESIGNATION,CREATED_BY_USER,CREATED_BY_DATE,MODIFIED_BY_USER,MODIFIED_BY_DATE) VALUES ('"+employee_id+"','"+employee_fname+"','"+employee_lname+"','"+employee_type+"','"+phone_no+"','"+email_id+"','"+employee_doj+"','"+employee_designation+"','"+CREATED_BY_USER+"','"+CREATED_BY_DATE+"','"+MODIFIED_BY_USER+"','"+MODIFIED_BY_DATE+"')");
	        int j=stmt.executeUpdate("insert into sys.EMPLOYEE_PERSONAL_INFO(EMPLOYEE_ID,EMPLOYEE_DOB,PHONE_NO2,FATHER_NAME,EMPLOYEE_ADDRESS1,EMPLOYEE_ADDRESS2,EMPLOYEE_ADDRESS3,CREATED_BY_USER,CREATED_BY_DATE,MODIFIED_BY_USER,MODIFIED_BY_DATE) VALUES ('"+employee_id+"','"+employee_dob+"','"+phone_no2+"','"+father_name+"','"+employee_address1+"','"+employee_address2+"','"+employee_address3+"','"+CREATED_BY_USER+"','"+CREATED_BY_DATE+"','"+MODIFIED_BY_USER+"','"+MODIFIED_BY_DATE+"' )"); 
	        int k=stmt.executeUpdate("insert into sys.EMPLOYER_INFO(EMPLOYEE_ID,PREVIOUS_EMPLOYER_NAME,FIN_YEAR,START_DATE,END_DATE,EMPLOYEE_SALARY,CREATED_BY_USER,CREATED_BY_DATE,MODIFIED_BY_USER,MODIFIED_BY_DATE)VALUES ('"+employee_id+"','"+previous_employer_name+"','"+fin_year+"','"+start_date+"','"+end_date+"','"+employee_salary+"','"+CREATED_BY_USER+"','"+CREATED_BY_DATE+"','"+MODIFIED_BY_USER+"','"+MODIFIED_BY_DATE+"')");
	    	
	       /* 		
	       ResultSet rs=stmt.executeQuery("select * from test_employee");  	    	
	    	
	    	while(rs.next()) 
	    	{	
	    	System.out.println(rs.getString(1)+" : "+rs.getString(2));  
	    	}
	    	*/	    	
	    /*	System.out.println(i+":"+j+":"+k);
	    	out.println("<br/>");
	    	out.println("Employee table updated...");
	    	emp_obj.invalidate();
	    	con.close();   
	    	}*/
	    	
	    	catch(Exception e)
	    	{ 
	    	//System.out.println(e);
	    	 out.println("<br/>");
	    	 //out.println("The exception occured is..."+e);
	    	 request.setAttribute("exception_message",e.getMessage());
	    	 RequestDispatcher rd=request.getRequestDispatcher("view/login-form.jsp");
	         rd.forward(request,response);      
	    	 }	        

		
	}
}
