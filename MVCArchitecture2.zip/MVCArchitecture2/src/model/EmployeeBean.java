package model;

public class EmployeeBean 
{
	private String employee_id,employee_fname,employee_lname,employee_dob,mobile_no,employee_doj,prev_emp_name,fin_year,tax_paid,phone_no,phone_no2,email_id,email_id2,father_name,employee_designation,employee_address1,employee_address2,employee_address3,employee_salary,employee_type,start_date,end_date;

	public String getEmployeeId()
	{		
		return employee_id;
	}	
	public void setEmployeeId(String employee_id)
	{
	     this.employee_id=employee_id; 		
	}	
	public String getEmployeeFname()
	{		
		return employee_fname;
	}	
	public void setEmployeeFname(String employee_fname)
	{
	     this.employee_fname=employee_fname; 		
	}	
	public String getEmployeeLname()
	{		
		return employee_lname;
	}	
	public void setEmployeeLname(String employee_lname)
	{
	     this.employee_lname=employee_lname; 		
	}	
	public String getEmployeeDob()
	{		
		return employee_dob;
	}	
	public void setEmployeeDob(String employee_dob)
	{
	     this.employee_dob=employee_dob; 		
	}
	public String getEmployeeDoj()
	{		
		return employee_doj;
	}	
	public void setEmployeeDoj(String employee_doj)
	{
	     this.employee_doj=employee_doj; 		
	}
	public String getPhoneNo()
	{
		return phone_no;
	}
	public void setPhoneNo(String phone_no)
	{
        this.phone_no=phone_no;		
	}
	
	public String getMobileNo()
	{
		return mobile_no;
	}	
	public void setMobileNo(String mobile_no)
	{
        this.mobile_no=mobile_no;		
	}
	public String getPhoneNo2()
	{
		return phone_no2;
	}
	public void setPhoneNo2(String phone_no2)
	{
        this.phone_no2=phone_no2;		
	}	
	public String getFatherName()
	{
		return father_name;
	}
	public void setFatherName(String father_name)
	{
        this.father_name=father_name;		
	}
	public String getEmailId()
	{
		return email_id;
	}
	public void setEmailId(String email_id)
	{
        this.email_id=email_id;		
	}	
	public String getEmailId2()
	{
		return email_id2;
	}
	public void setEmailId2(String email_id2)
	{
        this.email_id2=email_id2;		
	}			
	public String getDesignation()
	{
		return employee_designation;
	}
	public void setDesignation(String employee_designation)
	{
        this.employee_designation=employee_designation;		
	}	
	public String getEmployeeAddress1()
	{		
		return employee_address1;
	}		
	public void setEmployeeAddress1(String employee_address1)
	{
	     this.employee_address1=employee_address1; 		
	}

	public String getEmployeeAddress2()
	{		
		return employee_address2;
	}		
	public void setEmployeeAddress2(String employee_address2)
	{
	     this.employee_address2=employee_address2; 		
	}
	public String getEmployeeAddress3()
	{		
		return employee_address3;
	}		
	public void setEmployeeAddress3(String employee_address3)
	{
	     this.employee_address3=employee_address3; 		
	}		
	public String getEmployeeSalary()
	{		
		return employee_salary;
	}	
	public void setEmployeeSalary(String employee_salary)
	{
	    this.employee_salary=employee_salary; 		
	}	
	public String getEmployeeType()
	{		
		return employee_type;
	}	
	public void setEmployeeType(String employee_type)
	{
	     this.employee_type=employee_type; 		
	}	
	public String getStart_Date()
	{
		 return start_date;
	}
	public void setStart_Date(String start_date)
	{
		this.start_date=start_date;
	}	
	public String getEnd_Date()
	{
		 return end_date;
	}
	public void setEnd_Date(String end_date)
	{
		this.end_date=end_date;
	}
   	public String getPrev_Emp_Name()
    {
    	return prev_emp_name;    	
    }
	public void setPrev_Emp_Name(String prev_emp_name)
	{
		this.prev_emp_name=prev_emp_name;
	}
	public String getFin_Year()
    {
    	return fin_year;    	
    }
	public void setFin_Year(String fin_year)
	{
		this.fin_year=fin_year;
	}
	public String getTax_Paid()
    {
    	return tax_paid;    	
    }
	public void setTax_Paid(String tax_paid)
	{
		this.tax_paid=tax_paid;
	}	
}
